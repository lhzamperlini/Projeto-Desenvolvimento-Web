# Vanilla SPA
Single Page Application (SPA) construída com HTML, CSS e Vanilla JS

## Dados gerenciados com JSON Server
https://www.npmjs.com/package/json-server

## Instalação e execução
Clonar https://github.com/gilbriatore/vanilla.git e executar o comando vanilla.bat
